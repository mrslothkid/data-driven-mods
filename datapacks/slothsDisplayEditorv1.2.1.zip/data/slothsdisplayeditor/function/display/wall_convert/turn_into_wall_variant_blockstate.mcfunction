
$data modify entity @n[tag=sloths_display] block_state set from storage slothsdisplayeditor:dictionary replacenowall."$(id)"

