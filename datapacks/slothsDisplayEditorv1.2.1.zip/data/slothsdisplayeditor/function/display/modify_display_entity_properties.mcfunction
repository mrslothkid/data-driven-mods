


execute if score $modify_entity_axis slothsdisplayeditor.modify matches 1 run function slothsdisplayeditor:display/display_entitiy_properties/brightness
execute if score $modify_entity_axis slothsdisplayeditor.modify matches 2 run function slothsdisplayeditor:display/display_entitiy_properties/billboard
execute if score $modify_entity_axis slothsdisplayeditor.modify matches 3 run function slothsdisplayeditor:display/wall_convert
