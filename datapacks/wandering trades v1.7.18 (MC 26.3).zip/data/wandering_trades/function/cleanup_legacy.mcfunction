# Temporary trade-index items from the old implementation are no longer needed.
kill @e[type=minecraft:item,tag=trade_index_item]
