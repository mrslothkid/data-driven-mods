# Choose the count once, then draw without replacement from the original catalogue.
data modify storage wandering_trades:runtime work.pool set from storage wandering_trades:catalog blocks
execute store result score #remaining wt_random run random value 15..21
function wandering_trades:draw
