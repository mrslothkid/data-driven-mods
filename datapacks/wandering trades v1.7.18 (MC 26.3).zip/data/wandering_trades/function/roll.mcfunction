$execute store result storage wandering_trades:runtime work.index int 1 run random value 0..$(last)
