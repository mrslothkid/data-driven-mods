data merge entity @s {DeathTime:20}
kill @s
tp @s ~ ~-100 ~
stopsound @a[distance=..10] * minecraft:entity.baby_chicken.death
