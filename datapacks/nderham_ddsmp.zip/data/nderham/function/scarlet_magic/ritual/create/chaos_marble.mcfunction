summon marker ~ ~ ~ {Tags:["nderham.ritual.init","nderham.ritual","nderham.ritual.chaos_marble"]}
execute store result score @e[tag=nderham.ritual.init,limit=1,type=marker] nderham.ritual.id run random value 1..2147483647
execute store result storage nderham:ritual_visual_temp id int 1 run scoreboard players get @e[tag=nderham.ritual.init,limit=1,type=marker] nderham.ritual.id
data merge storage nderham:ritual_visual_temp {interp:25}

data merge storage nderham:ritual_visual_temp {distance:0,height:75,rx:0,ry:0,spin:113,item_model:"nderham:scarlet_rune_regulate"}
function nderham:scarlet_magic/ritual/visual/create with storage nderham:ritual_visual_temp

data merge storage nderham:ritual_visual_temp {distance:100,height:25,rx:0,ry:0,spin:225,item_model:"nderham:scarlet_rune_potency"}
function nderham:scarlet_magic/ritual/visual/create with storage nderham:ritual_visual_temp
data merge storage nderham:ritual_visual_temp {distance:110,height:25,rx:120,ry:0,spin:-225,item_model:"nderham:scarlet_rune_potency"}
function nderham:scarlet_magic/ritual/visual/create with storage nderham:ritual_visual_temp
data merge storage nderham:ritual_visual_temp {distance:120,height:25,rx:240,ry:0,spin:225,item_model:"nderham:scarlet_rune_potency"}
function nderham:scarlet_magic/ritual/visual/create with storage nderham:ritual_visual_temp

data merge storage nderham:ritual_visual_temp {distance:100,height:125,rx:60,ry:0,spin:225,item_model:"nderham:scarlet_rune_potency"}
function nderham:scarlet_magic/ritual/visual/create with storage nderham:ritual_visual_temp
data merge storage nderham:ritual_visual_temp {distance:110,height:125,rx:180,ry:0,spin:-225,item_model:"nderham:scarlet_rune_potency"}
function nderham:scarlet_magic/ritual/visual/create with storage nderham:ritual_visual_temp
data merge storage nderham:ritual_visual_temp {distance:120,height:125,rx:300,ry:0,spin:225,item_model:"nderham:scarlet_rune_potency"}
function nderham:scarlet_magic/ritual/visual/create with storage nderham:ritual_visual_temp

data merge storage nderham:ritual_visual_temp {distance:0,height:0,rx:0,ry:0,spin:450,item_model:"nderham:scarlet_core"}
function nderham:scarlet_magic/ritual/visual/create with storage nderham:ritual_visual_temp
data merge storage nderham:ritual_visual_temp {distance:0,height:150,rx:45,ry:0,spin:450,item_model:"nderham:scarlet_core"}
function nderham:scarlet_magic/ritual/visual/create with storage nderham:ritual_visual_temp

playsound minecraft:entity.illusioner.cast_spell player @a ~ ~ ~ 2 2
playsound minecraft:entity.illusioner.cast_spell player @a ~ ~ ~ 2 1
playsound minecraft:block.respawn_anchor.deplete player @a ~ ~ ~ 2 1.5
playsound minecraft:block.respawn_anchor.set_spawn player @a ~ ~ ~ 2 2
particle minecraft:flame ~ ~ ~ 0 0 0 0.1 10 normal
particle minecraft:electric_spark ~ ~ ~ 0 0 0 1 10 normal

tag @e[tag=nderham.ritual.init,limit=1,type=marker] remove nderham.ritual.init

#function nderham:scarlet_magic/ritual/visual/create {distance:-0.75,height:1.5,rx:0,ry:90,spin:338,item_model:"nderham:scarlet_emerald"}
#function nderham:scarlet_magic/ritual/visual/create {distance:-0.75,height:1.5,rx:45,ry:90,spin:113,item_model:"nderham:scarlet_emerald"}
#function nderham:scarlet_magic/ritual/visual/create {distance:-0.75,height:1.5,rx:90,ry:90,spin:338,item_model:"nderham:scarlet_emerald"}
#function nderham:scarlet_magic/ritual/visual/create {distance:-0.75,height:1.5,rx:135,ry:90,spin:113,item_model:"nderham:scarlet_emerald"}
#function nderham:scarlet_magic/ritual/visual/create {distance:-0.75,height:1.5,rx:180,ry:90,spin:338,item_model:"nderham:scarlet_emerald"}
#function nderham:scarlet_magic/ritual/visual/create {distance:-0.75,height:1.5,rx:225,ry:90,spin:113,item_model:"nderham:scarlet_emerald"}
#function nderham:scarlet_magic/ritual/visual/create {distance:-0.75,height:1.5,rx:270,ry:90,spin:338,item_model:"nderham:scarlet_emerald"}
#function nderham:scarlet_magic/ritual/visual/create {distance:-0.75,height:1.5,rx:315,ry:90,spin:113,item_model:"nderham:scarlet_emerald"}


