summon marker ~ ~ ~ {Tags:["nderham.ritual.init","nderham.ritual","nderham.ritual.furnace_beam"]}
summon marker ~ ~ ~ {Tags:["nderham.ritual.furnace_beam.aim.init","nderham.ritual.furnace_beam.aim"]}
summon marker ~ ~ ~ {Tags:["nderham.ritual.furnace_beam.slow_aim.init","nderham.ritual.furnace_beam.slow_aim"]}
summon interaction ~ ~ ~ {Tags:["nderham.ritual.furnace_beam.interaction.init","nderham.ritual.furnace_beam.interaction"],height:1,width:1}
rotate @e[tag=nderham.ritual.init,limit=1,type=marker] ~ ~
rotate @e[tag=nderham.ritual.furnace_beam.slow_aim.init,limit=1,type=marker] ~ ~
execute store result score @e[tag=nderham.ritual.init,limit=1,type=marker] nderham.ritual.id run random value 1..2147483647
execute store result storage nderham:ritual_visual_temp id int 1 run scoreboard players get @e[tag=nderham.ritual.init,limit=1,type=marker] nderham.ritual.id
scoreboard players operation @e[tag=nderham.ritual.furnace_beam.aim.init,limit=1,type=marker] nderham.ritual.id = @e[tag=nderham.ritual.init,limit=1,type=marker] nderham.ritual.id
scoreboard players operation @e[tag=nderham.ritual.furnace_beam.slow_aim.init,limit=1,type=marker] nderham.ritual.id = @e[tag=nderham.ritual.init,limit=1,type=marker] nderham.ritual.id
scoreboard players operation @e[tag=nderham.ritual.furnace_beam.interaction.init,limit=1,type=interaction] nderham.ritual.id = @e[tag=nderham.ritual.init,limit=1,type=marker] nderham.ritual.id
data merge storage nderham:ritual_visual_temp {start_interp:24,no_spin:1}

data merge storage nderham:ritual_visual_temp {interp:2,distance:25,rx:0,ry:0,spin:3,item_model:"nderham:scarlet_rune_regulate"}
function nderham:scarlet_magic/ritual/visual/create_directional with storage nderham:ritual_visual_temp
data merge storage nderham:ritual_visual_temp {interp:2,distance:100,rx:0,ry:0,spin:-5,item_model:"nderham:scarlet_rune_potency"}
function nderham:scarlet_magic/ritual/visual/create_directional with storage nderham:ritual_visual_temp
data merge storage nderham:ritual_visual_temp {interp:2,distance:50,rx:0,ry:0,spin:10,item_model:"nderham:furnace_beam_outer"}
function nderham:scarlet_magic/ritual/visual/create_directional with storage nderham:ritual_visual_temp
data merge storage nderham:ritual_visual_temp {start_interp:2,interp:2,distance:0,rx:0,ry:0,spin:2,item_model:"nderham:furnace_beam_gold_ring",no_spin:0}
function nderham:scarlet_magic/ritual/visual/create_directional with storage nderham:ritual_visual_temp
data merge storage nderham:ritual_visual_temp {start_interp:24,interp:1,distance:55,rx:0,ry:0,spin:16,item_model:"nderham:scarlet_core_rotated",no_spin:1}
function nderham:scarlet_magic/ritual/visual/create_directional with storage nderham:ritual_visual_temp

playsound minecraft:entity.illusioner.cast_spell player @a ~ ~ ~ 2 2
playsound minecraft:entity.illusioner.cast_spell player @a ~ ~ ~ 2 1
playsound minecraft:block.respawn_anchor.deplete player @a ~ ~ ~ 2 1.5
playsound minecraft:block.respawn_anchor.set_spawn player @a ~ ~ ~ 2 2
particle minecraft:flame ~ ~ ~ 0 0 0 0.1 10 normal
particle minecraft:electric_spark ~ ~ ~ 0 0 0 1 10 normal

tag @e[tag=nderham.ritual.init,limit=1,type=marker] remove nderham.ritual.init
tag @e[tag=nderham.ritual.furnace_beam.aim.init,limit=1,type=marker] remove nderham.ritual.furnace_beam.aim.init
tag @e[tag=nderham.ritual.furnace_beam.slow_aim.init,limit=1,type=marker] remove nderham.ritual.furnace_beam.slow_aim.init
tag @e[tag=nderham.ritual.furnace_beam.interaction.init,limit=1,type=interaction] remove nderham.ritual.furnace_beam.interaction.init