execute if score ritual.chaos_marble.fire_raycast nderham.value matches 30.. run return 0
scoreboard players add ritual.chaos_marble.fire_raycast nderham.value 1
#particle flame ~ ~ ~ 0 0 0 0 1 force
execute positioned ^ ^ ^0.5 if block ~ ~ ~ air run return run function nderham:scarlet_magic/ritual/type/chaos_marble/fire_raycast
execute unless block ^ ^ ^0.5 air run return run fill ~ ~1 ~ ~ ~-1 ~ fire replace air