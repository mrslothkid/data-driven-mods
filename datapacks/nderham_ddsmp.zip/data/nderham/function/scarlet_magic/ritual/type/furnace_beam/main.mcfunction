$tp @e[tag=nderham.ritual.furnace_beam.aim,limit=1,scores={nderham.ritual.id=$(id)}] ^ ^ ^1 ~ ~
$tp @e[tag=nderham.ritual.furnace_beam.interaction,limit=1,scores={nderham.ritual.id=$(id)}] ~ ~-.5 ~ ~ ~
$execute positioned ^ ^ ^-1 rotated as @e[tag=nderham.ritual.furnace_beam.slow_aim,limit=1,scores={nderham.ritual.id=$(id)}] positioned ^ ^ ^-.05 facing entity @s feet run rotate @s ~ ~
$execute as @e[tag=nderham.ritual.visual_directional,scores={nderham.ritual.id=$(id)}] run rotate @s ~ ~
scoreboard players set ritual.furnace_beam.raycast_step nderham.value 0
execute store result storage nderham:furnace_beam x float 0.1 run random value -2..2
execute store result storage nderham:furnace_beam y float 0.1 run random value -2..2
execute store result storage nderham:furnace_beam rx float 0.1 run random value -15..15
execute store result storage nderham:furnace_beam ry float 0.1 run random value -15..15
$execute as @e[tag=nderham.ritual.furnace_beam.aim,limit=1,scores={nderham.ritual.id=$(id)}] at @s run function nderham:scarlet_magic/ritual/type/furnace_beam/random_transform with storage nderham:furnace_beam
$execute if score @s nderham.ritual.time matches 24.. as @e[tag=nderham.ritual.furnace_beam.aim,limit=1,scores={nderham.ritual.id=$(id)}] at @s run function nderham:scarlet_magic/ritual/type/furnace_beam/raycast
execute if score @s nderham.ritual.time matches 24 run function nderham:scarlet_magic/ritual/visual/enable_spin with storage nderham:ritual
execute if score @s nderham.ritual.time matches 24 run function nderham:scarlet_magic/ritual/visual/apply_interp with storage nderham:ritual
execute if score @s nderham.ritual.time matches 24.. run particle small_flame ^ ^ ^.55 0.1 0.1 0.1 .01 1 normal
execute if score @s nderham.ritual.time matches 24.. run particle electric_spark ^ ^ ^1.25 0.1 0.1 0.1 0 1 force
execute if score @s nderham.ritual.time matches 24.. run playsound minecraft:entity.warden.ambient player @a ^ ^ ^.5 1 1.5
execute if score @s nderham.ritual.time matches 24 run playsound minecraft:entity.warden.sonic_boom player @a ~ ~ ~ 1 2
execute if score @s nderham.ritual.time matches 24 run playsound minecraft:entity.warden.sonic_boom player @a ~ ~ ~ 1 1.5
execute if score @s nderham.ritual.time matches 24 run playsound minecraft:entity.generic.explode player @a ~ ~ ~ 1 1.5
execute if score @s nderham.ritual.time matches 24 run particle flash{color:[1,1,1,1]} ^ ^ ^1 0 0 0 0 1 force
execute if entity @e[type=arrow,sort=nearest,distance=..1.5] run tag @s add nderham.ritual.furnace_beam.unstable
execute as @e[type=arrow,sort=nearest,distance=..1.5] run playsound minecraft:block.respawn_anchor.deplete player @a ~ ~ ~ 1 0.75
execute as @e[type=arrow,sort=nearest,distance=..1.5] run kill @s
scoreboard players add @s[tag=nderham.ritual.furnace_beam.unstable] nderham.ritual.damage 1
execute if score @s nderham.ritual.damage matches 200.. run function nderham:scarlet_magic/furance_beam/delete with storage nderham:ritual
execute if score @s nderham.ritual.time matches 4800.. run function nderham:scarlet_magic/furance_beam/delete with storage nderham:ritual
execute if entity @s[tag=nderham.ritual.furnace_beam.unstable] run rotate @s ~5 ~
execute if entity @s[tag=nderham.ritual.furnace_beam.unstable] run particle flame ^ ^ ^.5 0.25 0.25 0.25 0.25 10 force
$execute if entity @s[tag=nderham.ritual.furnace_beam.unstable] run rotate @e[tag=nderham.ritual.furnace_beam.slow_aim,limit=1,scores={nderham.ritual.id=$(id)}] ~ ~
