execute store result storage nderham:ritual id int 1 run scoreboard players get @s nderham.ritual.id
execute if score @s nderham.ritual.time matches 25 run function nderham:scarlet_magic/ritual/visual/delete with storage nderham:ritual
#execute if score @s nderham.ritual.time matches 15.. run summon fireball ~ ~ ~ {ExplosionPower:5,Motion:[0.0,-1.0,0.0],CustomName:"Cardinal Chaos Marble Explosion"}
execute if score @s nderham.ritual.time matches 25 run summon creeper ~ ~1 ~ {Invulnerable:true,ExplosionRadius:10,ignited:true,Fuse:0,CustomName:"Cardinal Chaos Marble explosion"}
execute if score @s nderham.ritual.time matches 25 run playsound minecraft:entity.generic.explode block @a ~ ~ ~ 2 0.75
execute if score @s nderham.ritual.time matches 25 run playsound minecraft:entity.generic.explode block @a ~ ~ ~ 4 0.5
execute if score @s nderham.ritual.time matches 25 run playsound entity.lightning_bolt.thunder block @a ~ ~ ~ 2 2
execute if score @s nderham.ritual.time matches 25 run particle flame ~ ~ ~ 0 0 0 0.5 100 normal
#execute if score @s nderham.ritual.time matches 25.. run particle campfire_signal_smoke ~ ~ ~ 0 0 0 0.5 100 normal
#execute if score @s nderham.ritual.time matches 15.. run setblock ~ ~-1 ~ dirt
execute if score @s nderham.ritual.time matches 1.. run function nderham:scarlet_magic/ritual/type/chaos_marble/fire
execute if score @s nderham.ritual.time matches 26 run function nderham:scarlet_magic/ritual/type/chaos_marble/fire_boom
execute if score @s nderham.ritual.time matches 26.. run kill @s