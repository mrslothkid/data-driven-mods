scoreboard players set ritual.chaos_marble.fire_raycast nderham.value 0
execute store result entity @s Rotation[0] float 0.01 run random value -18000..18000
execute store result entity @s Rotation[1] float 0.01 run random value -9000..9000
execute rotated as @s run function nderham:scarlet_magic/ritual/type/chaos_marble/fire_raycast