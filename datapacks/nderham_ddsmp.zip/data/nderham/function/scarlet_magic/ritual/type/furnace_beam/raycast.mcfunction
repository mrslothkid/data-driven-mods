execute if score ritual.furnace_beam.raycast_step nderham.value matches 200.. run return 0
scoreboard players add ritual.furnace_beam.raycast_step nderham.value 1
#particle bubble_pop ~ ~ ~ ^ ^ ^10000000 0.000001 0 force
particle bubble_pop ~ ~ ~ 0.5 0.5 0.5 0 1 force
execute positioned ~-.5 ~-.5 ~-.5 as @e[dx=0,dy=0,dz=0,type=!item] positioned ~.5 ~.5 ~.5 run damage @s 30 nderham:furnace_beam
execute positioned ~-.5 ~-.5 ~-.5 as @e[dx=0,dy=0,dz=0,tag=nderham.ritual.furnace_beam,tag=!nderham.ritual.furnace_beam.unstable] positioned ~.5 ~.5 ~.5 run playsound minecraft:block.respawn_anchor.deplete player @a ~ ~ ~ 1 0.75
execute positioned ~-.5 ~-.5 ~-.5 as @e[dx=0,dy=0,dz=0,tag=nderham.ritual.furnace_beam,tag=!nderham.ritual.furnace_beam.unstable] positioned ~.5 ~.5 ~.5 run tag @s add nderham.ritual.furnace_beam.unstable
#execute positioned ~-.5 ~-.5 ~-.5 as @e[dx=0,dy=0,dz=0] positioned ~.5 ~.5 ~.5 at @s run summon minecraft:small_fireball ~ ~1.9 ~ {Motion:[0,-2,0]}
execute positioned ^ ^ ^0.5 if block ~ ~ ~ #nderham:furnace_beam_through run return run function nderham:scarlet_magic/ritual/type/furnace_beam/raycast
#execute unless block ^ ^ ^0.5 air run particle flash{color:[1.0,1.0,1.0,1.0]} ^ ^ ^1 0.1 0.1 0.1 0 1 force
execute unless block ^ ^ ^0.5 air positioned ^ ^ ^0.5 run playsound minecraft:block.fire.ambient block @a ~ ~ ~ 1 2
execute unless block ^ ^ ^0.5 air positioned ^ ^ ^0.5 run function nderham:burn_replace
execute unless block ^ ^ ^0.5 air unless block ^ ^ ^0.5 #nderham:burn/non_burnable positioned ^ ^ ^ run fill ~ ~ ~ ~ ~ ~ fire replace air
