execute store result storage nderham:ritual id int 1 run scoreboard players get @s nderham.ritual.id
function nderham:scarlet_magic/ritual/type/furnace_beam/main with storage nderham:ritual
