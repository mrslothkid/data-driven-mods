execute as @e[tag=nderham.ritual.visual,type=item_display] at @s run function nderham:scarlet_magic/ritual/visual/main
execute as @e[tag=nderham.ritual.visual_directional,type=item_display] at @s run function nderham:scarlet_magic/ritual/visual/main_directional

scoreboard players add @e[tag=nderham.ritual.visual_directional,type=marker] nderham.ritual.time 1
scoreboard players add @e[tag=nderham.ritual,type=marker] nderham.ritual.time 1

execute as @e[tag=nderham.ritual.chaos_marble,type=marker] at @s run function nderham:scarlet_magic/ritual/type/chaos_marble
execute as @e[tag=nderham.ritual.furnace_beam,type=marker] at @s run function nderham:scarlet_magic/ritual/type/furnace_beam