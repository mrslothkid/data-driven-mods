$kill @e[tag=nderham.ritual.visual,scores={nderham.ritual.id=$(id)}]
$kill @e[tag=nderham.ritual.visual_directional,scores={nderham.ritual.id=$(id)}]