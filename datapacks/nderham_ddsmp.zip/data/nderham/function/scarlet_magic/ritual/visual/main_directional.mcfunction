execute store result storage nderham:ritual_visual distance float .01 run scoreboard players get @s nderham.ritual.visual.distance
execute store result storage nderham:ritual_visual height float .01 run scoreboard players get @s nderham.ritual.visual.height
execute if entity @s[tag=nderham.ritual.visual.init.tick] run function nderham:scarlet_magic/ritual/visual/init_tick with storage nderham:ritual_visual
execute if entity @s[tag=!nderham.ritual.visual_directional.no_spin] run scoreboard players operation @s nderham.ritual.visual.directional_rot += @s nderham.ritual.visual.spin
execute if entity @s[tag=!nderham.ritual.visual_directional.no_spin] run execute store result storage nderham:ritual_visual_rotate rot float 0.1 run scoreboard players get @s nderham.ritual.visual.directional_rot
execute if entity @s[tag=!nderham.ritual.visual_directional.no_spin] run function nderham:scarlet_magic/ritual/visual/rotate_directional with storage nderham:ritual_visual_rotate