$summon item_display ~ ~ ~ {teleport_duration:3,interpolation_duration:$(start_interp),brightness:{block:15,sky:0},Tags:["nderham.ritual.visual_directional","nderham.ritual.visual.init","nderham.ritual.visual.init.tick"],item:{id:"yellow_wool",components:{enchantment_glint_override:true,item_model:"nderham:scarlet_rune"}},transformation:{left_rotation:[0.0,0.0,0.0,1.0],right_rotation:[0.0,0.0,0.0,1.0],scale:[0.5,0.5,0.5],translation:[0.0,0.0,0.0]}}
$scoreboard players set @e[tag=nderham.ritual.visual.init,limit=1,type=item_display] nderham.ritual.id $(id)
$scoreboard players set @e[tag=nderham.ritual.visual.init,limit=1,type=item_display] nderham.ritual.visual.distance $(distance)
$scoreboard players set @e[tag=nderham.ritual.visual.init,limit=1,type=item_display] nderham.ritual.visual.interp $(interp)
scoreboard players set @e[tag=nderham.ritual.visual.init,limit=1,type=item_display] nderham.ritual.visual.height 0
$execute if score $1 nderham.math matches $(no_spin) run tag @e[tag=nderham.ritual.visual.init,limit=1,type=item_display] add nderham.ritual.visual_directional.no_spin
rotate @e[tag=nderham.ritual.visual.init,limit=1,type=item_display] ~ ~
$scoreboard players set @e[tag=nderham.ritual.visual.init,limit=1,type=item_display] nderham.ritual.visual.spin $(spin)
$data modify entity @e[tag=nderham.ritual.visual.init,limit=1,type=item_display] item.components.minecraft:item_model set value "$(item_model)"
tag @e[tag=nderham.ritual.visual.init,limit=1,type=item_display] remove nderham.ritual.visual.init