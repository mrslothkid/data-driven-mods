execute store result storage nderham:ritual_visual distance float .01 run scoreboard players get @s nderham.ritual.visual.distance
execute store result storage nderham:ritual_visual height float .01 run scoreboard players get @s nderham.ritual.visual.height
execute if entity @s[tag=nderham.ritual.visual.init.tick] run function nderham:scarlet_magic/ritual/visual/init_tick with storage nderham:ritual_visual
execute store result storage nderham:ritual_visual_rotate rot float 0.1 run scoreboard players get @s nderham.ritual.visual.spin
function nderham:scarlet_magic/ritual/visual/rotate with storage nderham:ritual_visual_rotate