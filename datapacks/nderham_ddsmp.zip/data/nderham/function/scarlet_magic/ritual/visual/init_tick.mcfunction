$data modify entity @s transformation.translation[2] set value $(distance)
$data modify entity @s transformation.translation[1] set value $(height)
tag @s remove nderham.ritual.visual.init.tick