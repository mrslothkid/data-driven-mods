#15
execute as @e[type=item,nbt={Item:{id:"minecraft:stray_spawn_egg"}}] at @s positioned ~ ~.5 ~ align xyz positioned ~.5 ~.5 ~.5 if block ~ ~ ~ cauldron run function nderham:scarlet_magic/thunder_alter/item2core
execute as @e[tag=nderham.thunder_alter.core_glow,limit=1,sort=random,type=item_display] at @s unless entity @e[tag=nderham.thunder_alter.core,type=item_display,limit=1,sort=nearest,distance=..1] run kill @s
execute as @e[tag=nderham.thunder_alter.core,type=item_display] at @s run function nderham:scarlet_magic/thunder_alter/core
