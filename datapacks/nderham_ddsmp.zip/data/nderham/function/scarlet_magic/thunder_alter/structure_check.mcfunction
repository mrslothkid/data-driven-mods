scoreboard players set thunder_alter.check nderham.value 0

execute if block ~ ~ ~ cauldron run scoreboard players add thunder_alter.check nderham.value 1
execute if block ~ ~-1 ~ lodestone run scoreboard players add thunder_alter.check nderham.value 1
execute if block ~ ~-2 ~ iron_block run scoreboard players add thunder_alter.check nderham.value 1

execute if block ~1 ~-2 ~ polished_andesite_stairs[facing=west,half=top,shape=straight] run scoreboard players add thunder_alter.check nderham.value 1
execute if block ~ ~-2 ~1 polished_andesite_stairs[facing=north,half=top,shape=straight] run scoreboard players add thunder_alter.check nderham.value 1
execute if block ~-1 ~-2 ~ polished_andesite_stairs[facing=east,half=top,shape=straight] run scoreboard players add thunder_alter.check nderham.value 1
execute if block ~ ~-2 ~-1 polished_andesite_stairs[facing=south,half=top,shape=straight] run scoreboard players add thunder_alter.check nderham.value 1

execute if block ~1 ~-1 ~ iron_bars run scoreboard players add thunder_alter.check nderham.value 1
execute if block ~ ~-1 ~1 iron_bars run scoreboard players add thunder_alter.check nderham.value 1
execute if block ~-1 ~-1 ~ iron_bars run scoreboard players add thunder_alter.check nderham.value 1
execute if block ~ ~-1 ~-1 iron_bars run scoreboard players add thunder_alter.check nderham.value 1

execute if block ~1 ~ ~ redstone_torch run scoreboard players add thunder_alter.check nderham.value 1
execute if block ~ ~ ~1 redstone_torch run scoreboard players add thunder_alter.check nderham.value 1
execute if block ~-1 ~ ~ redstone_torch run scoreboard players add thunder_alter.check nderham.value 1
execute if block ~ ~ ~-1 redstone_torch run scoreboard players add thunder_alter.check nderham.value 1

