$playsound minecraft:block.beacon.ambient block @a ~ ~ ~ $(pitch1) $(pitch2)
$playsound minecraft:block.beacon.ambient block @a ~ ~ ~ $(pitch2) $(pitch1)
$playsound minecraft:block.beacon.power_select block @a ~ ~ ~ $(pitch1) $(pitch2)
$playsound minecraft:block.beacon.power_select block @a ~ ~ ~ $(pitch2) $(pitch1)
#particle electric_spark ~ ~ ~ 0.125 0.125 0.125 0.1 10 force