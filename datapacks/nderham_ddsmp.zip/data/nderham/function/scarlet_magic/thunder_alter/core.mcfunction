execute if block ~ ~ ~ water_cauldron run return run function nderham:scarlet_magic/thunder_alter/core_pop
execute if block ~ ~ ~ powder_snow_cauldron run return run function nderham:scarlet_magic/thunder_alter/core_pop
execute align xyz positioned ~.5 ~.5 ~.5 run function nderham:scarlet_magic/thunder_alter/structure_check
execute unless score thunder_alter.check nderham.value matches 15 run summon lightning_bolt ~ ~ ~
execute unless score thunder_alter.check nderham.value matches 15 run summon creeper ~ ~ ~ {Invulnerable:true,ExplosionRadius:5b,Fuse:0,ignited:1b,CustomName:"Scarlet Core"}
execute unless score thunder_alter.check nderham.value matches 15 run playsound minecraft:entity.generic.explode block @a ~ ~ ~ 2 0.5
execute unless score thunder_alter.check nderham.value matches 15 run kill @e[tag=nderham.thunder_alter.core_glow,limit=1,sort=nearest,distance=..1,type=item_display]
execute unless score thunder_alter.check nderham.value matches 15 run return run kill @s

rotate @s ~89 22.5
execute store success entity @s OnGround byte 1 store success score @s nderham.rot_fix unless score @s nderham.rot_fix matches 1

particle small_flame ~ ~ ~ 0.02 0.02 0.02 0.005 1 force

execute rotated ~ 0 run particle dust{color:[1.000,0.000,0.267],scale:1} ^ ^.05 ^1 0.05 0.05 0.05 0 5 force
execute rotated ~22.5 0 run particle dust{color:[1.000,0.000,0.267],scale:1} ^ ^.05 ^1 0.05 0.05 0.05 0 5 force
execute rotated ~45 0 run particle dust{color:[1.000,0.000,0.267],scale:1} ^ ^.05 ^1 0.05 0.05 0.05 0 5 force
execute rotated ~67.5 0 run particle dust{color:[1.000,0.000,0.267],scale:1} ^ ^.05 ^1 0.05 0.05 0.05 0 5 force

#execute rotated ~ 0 positioned ^ ^320 ^50 positioned over motion_blocking_no_leaves run particle electric_spark ~ ~.5 ~ 0.5 1 0.5 1 5 force
#execute rotated ~11.25 0 positioned ^ ^320 ^50 positioned over motion_blocking_no_leaves run particle electric_spark ~ ~.5 ~ 0.5 1 0.5 1 5 force
#execute rotated ~22.5 0 positioned ^ ^320 ^50 positioned over motion_blocking_no_leaves run particle electric_spark ~ ~.5 ~ 0.5 1 0.5 1 5 force
#execute rotated ~33.75 0 positioned ^ ^320 ^50 positioned over motion_blocking_no_leaves run particle electric_spark ~ ~.5 ~ 0.5 1 0.5 1 5 force
#execute rotated ~45 0 positioned ^ ^320 ^50 positioned over motion_blocking_no_leaves run particle electric_spark ~ ~.5 ~ 0.5 1 0.5 1 5 force
#execute rotated ~56.25 0 positioned ^ ^320 ^50 positioned over motion_blocking_no_leaves run particle electric_spark ~ ~.5 ~ 0.5 1 0.5 1 5 force
#execute rotated ~67.5 0 positioned ^ ^320 ^50 positioned over motion_blocking_no_leaves run particle electric_spark ~ ~.5 ~ 0.5 1 0.5 1 5 force
#execute rotated ~78.75 0 positioned ^ ^320 ^50 positioned over motion_blocking_no_leaves run particle electric_spark ~ ~.5 ~ 0.5 1 0.5 1 5 force

#execute rotated ~ 0 positioned ^ ^320 ^50 positioned over motion_blocking_no_leaves positioned ~ ~5 ~ facing entity @s feet run particle electric_spark ~ ~ ~ ^ ^ ^10000000 0.000001 0 force
#execute rotated ~11.25 0 positioned ^ ^320 ^50 positioned over motion_blocking_no_leaves positioned ~ ~5 ~ facing entity @s feet run particle electric_spark ~ ~ ~ ^ ^ ^10000000 0.000001 0 force
#execute rotated ~22.5 0 positioned ^ ^320 ^50 positioned over motion_blocking_no_leaves positioned ~ ~5 ~ facing entity @s feet run particle electric_spark ~ ~ ~ ^ ^ ^10000000 0.000001 0 force
#execute rotated ~33.75 0 positioned ^ ^320 ^50 positioned over motion_blocking_no_leaves positioned ~ ~5 ~ facing entity @s feet run particle electric_spark ~ ~ ~ ^ ^ ^10000000 0.000001 0 force
#execute rotated ~45 0 positioned ^ ^320 ^50 positioned over motion_blocking_no_leaves positioned ~ ~5 ~ facing entity @s feet run particle electric_spark ~ ~ ~ ^ ^ ^10000000 0.000001 0 force
#execute rotated ~56.25 0 positioned ^ ^320 ^50 positioned over motion_blocking_no_leaves positioned ~ ~5 ~ facing entity @s feet run particle electric_spark ~ ~ ~ ^ ^ ^10000000 0.000001 0 force
#execute rotated ~67.5 0 positioned ^ ^320 ^50 positioned over motion_blocking_no_leaves positioned ~ ~5 ~ facing entity @s feet run particle electric_spark ~ ~ ~ ^ ^ ^10000000 0.000001 0 force
#execute rotated ~78.75 0 positioned ^ ^320 ^50 positioned over motion_blocking_no_leaves positioned ~ ~5 ~ facing entity @s feet run particle electric_spark ~ ~ ~ ^ ^ ^10000000 0.000001 0 force

#for detecting when entities leave or enter the charge zone to do discharging and etc
#tag @s add nderham.thunder_alter.core.current

#execute as @e[distance=..384] if predicate nderham:altar_in_zone at @s run function nderham:scarlet_magic/thunder_alter/entity_zone

#tag @s remove nderham.thunder_alter.core.current

execute positioned ~ ~-.5 ~ as @e[type=item,sort=nearest,distance=..0.5] if data entity @s Item{id:"minecraft:blaze_powder"} run scoreboard players add @e[tag=nderham.thunder_alter.core,limit=1,sort=nearest] nderham.thunder_alter.fuel 1
execute positioned ~ ~-.5 ~ as @e[type=item,sort=nearest,distance=..0.5] if data entity @s Item{id:"minecraft:blaze_powder"} run kill @s
execute positioned ~ ~-.5 ~ as @e[type=item,sort=nearest,distance=..0.5] unless data entity @s Item{id:"minecraft:blaze_powder"} run kill @s

scoreboard players add @s nderham.thunder_alter.fuel 0
execute if score @s nderham.thunder_alter.fuel matches ..0 run scoreboard players set @s nderham.thunder_alter.fuel 1
scoreboard players operation @s nderham.thunder_alter.charge += @s nderham.thunder_alter.fuel


scoreboard players add @s nderham.thunder_alter.sound_loop 1
execute store result storage nderham:thunder_altar pitch2 float 0.000208333333 run scoreboard players get @s nderham.thunder_alter.charge
execute store result storage nderham:thunder_altar pitch1 float 0.000104166667 run scoreboard players get @s nderham.thunder_alter.charge
execute if score @s nderham.thunder_alter.sound_loop matches 5.. run function nderham:scarlet_magic/thunder_alter/sound with storage nderham:thunder_altar
execute if score @s nderham.thunder_alter.sound_loop matches 5.. run scoreboard players set @s nderham.thunder_alter.sound_loop 0

execute if score @s nderham.thunder_alter.charge matches 9600.. run playsound minecraft:block.respawn_anchor.deplete block @a ~ ~ ~ 2 0.5
execute if score @s nderham.thunder_alter.charge matches 9600.. run playsound minecraft:block.respawn_anchor.deplete block @a ~ ~ ~ 2 1
execute if score @s nderham.thunder_alter.charge matches 9600.. run playsound minecraft:block.respawn_anchor.deplete block @a ~ ~ ~ 2 2
execute if score @s nderham.thunder_alter.charge matches 9600.. run playsound minecraft:entity.generic.explode block @a ~ ~ ~ 2 1.5
execute if score @s nderham.thunder_alter.charge matches 9600.. unless entity @e[tag=nderham.lightning_craft.marker,distance=..50,type=marker] run summon lightning_bolt ~ ~.5 ~
execute if score @s nderham.thunder_alter.charge matches 9600.. if entity @e[tag=nderham.lightning_craft.marker,distance=..50,type=marker] as @e[tag=nderham.lightning_craft.marker,distance=..50,type=marker,limit=1,sort=random] at @s positioned ~ ~1.5 ~ run summon lightning_bolt



execute if score @s nderham.thunder_alter.charge matches 9600.. positioned ~ ~ ~ run particle minecraft:electric_spark ~0.5 ~ ~0.5 0 0.25 0 0.1 10 force
execute if score @s nderham.thunder_alter.charge matches 9600.. positioned ~ ~ ~ run particle minecraft:electric_spark ~-0.5 ~ ~0.5 0 0.25 0 0.1 10 force
execute if score @s nderham.thunder_alter.charge matches 9600.. positioned ~ ~ ~ run particle minecraft:electric_spark ~0.5 ~ ~-0.5 0 0.25 0 0.1 10 force
execute if score @s nderham.thunder_alter.charge matches 9600.. positioned ~ ~ ~ run particle minecraft:electric_spark ~-0.5 ~ ~-0.5 0 0.25 0 0.1 10 force

execute if score @s nderham.thunder_alter.charge matches 9600.. positioned ~ ~ ~ run particle minecraft:electric_spark ~0.5 ~0.5 ~ 0 0 0.25 0.1 10 force
execute if score @s nderham.thunder_alter.charge matches 9600.. positioned ~ ~ ~ run particle minecraft:electric_spark ~-0.5 ~0.5 ~ 0 0 0.25 0.1 10 force
execute if score @s nderham.thunder_alter.charge matches 9600.. positioned ~ ~ ~ run particle minecraft:electric_spark ~0.5 ~-0.5 ~ 0 0 0.25 0.1 10 force
execute if score @s nderham.thunder_alter.charge matches 9600.. positioned ~ ~ ~ run particle minecraft:electric_spark ~-0.5 ~-0.5 ~ 0 0 0.25 0.1 10 force

execute if score @s nderham.thunder_alter.charge matches 9600.. positioned ~ ~ ~ run particle minecraft:electric_spark ~ ~0.5 ~0.5 0.25 0 0 0.1 10 force
execute if score @s nderham.thunder_alter.charge matches 9600.. positioned ~ ~ ~ run particle minecraft:electric_spark ~ ~-0.5 ~0.5 0.25 0 0 0.1 10 force
execute if score @s nderham.thunder_alter.charge matches 9600.. positioned ~ ~ ~ run particle minecraft:electric_spark ~ ~0.5 ~-0.5 0.25 0 0 0.1 10 force
execute if score @s nderham.thunder_alter.charge matches 9600.. positioned ~ ~ ~ run particle minecraft:electric_spark ~ ~-0.5 ~-0.5 0.25 0 0 0.1 10 force

execute if score @s nderham.thunder_alter.charge matches 9600.. run particle electric_spark ~ ~1 ~ 0 1 0 1 100 force

execute if score @s nderham.thunder_alter.charge matches 9600.. run scoreboard players set @s nderham.thunder_alter.charge 0