summon item ~ ~ ~ {Item:{id:stray_spawn_egg,components:{"item_name":"Scarlet Core","item_model":"nderham:scarlet_core","enchantment_glint_override":true,"max_stack_size":1,"custom_data":{scarlet_core:1b},"!entity_data":{},"rarity":"uncommon"},count:1},Motion:[0.0,0.5,0.0]}
particle large_smoke ~ ~ ~ 0.25 0.25 0.25 0.0 5 force
playsound minecraft:block.lava.extinguish block @a ~ ~ ~ 1 1
playsound minecraft:block.respawn_anchor.charge block @a ~ ~ ~ 1 0.5
playsound minecraft:block.respawn_anchor.deplete block @a ~ ~ ~ 0.5 0.5
kill @s
kill @e[tag=nderham.thunder_alter.core_glow,limit=1,sort=nearest,distance=..1,type=item_display]