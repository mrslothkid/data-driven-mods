function nderham:scarlet_magic/thunder_alter/structure_check

execute if score thunder_alter.check nderham.value matches 15 unless entity @e[tag=nderham.thunder_alter.core,limit=1,sort=nearest,distance=..0.25,type=item_display] run return run function nderham:scarlet_magic/thunder_alter/create_core

execute if score thunder_alter.check nderham.value matches 15 if entity @e[tag=nderham.thunder_alter.core,limit=1,sort=nearest,distance=..0.25,type=item_display] run setblock ~ ~ ~ fire
