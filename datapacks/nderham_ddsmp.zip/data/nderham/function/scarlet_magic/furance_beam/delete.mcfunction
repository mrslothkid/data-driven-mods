execute store result storage nderham:ritual id int 1 run scoreboard players get @s nderham.ritual.id
function nderham:scarlet_magic/ritual/visual/delete with storage nderham:ritual
function nderham:scarlet_magic/furance_beam/delete_2nd with storage nderham:ritual

summon item ^ ^.5 ^.5 {Item:{id:"minecraft:ender_dragon_spawn_egg",components:{"!entity_data":{},"item_model":"nderham:scarlet_rune_intent","minecraft:item_name": "Scarlet Rune","minecraft:rarity": "uncommon","enchantment_glint_override": true,"enchantments":{"nderham:intent":1}}}}
summon item ^ ^.5 ^.5 {Item:{id:"minecraft:ender_dragon_spawn_egg",components:{"!entity_data":{},"item_model":"nderham:scarlet_rune_intent","minecraft:item_name": "Scarlet Rune","minecraft:rarity": "uncommon","enchantment_glint_override": true,"enchantments":{"nderham:intent":1}}}}
summon item ^ ^.5 ^.5 {Item:{id:"minecraft:endermite_spawn_egg",components:{"!entity_data":{},"item_model":"nderham:scarlet_rune_potency","minecraft:item_name": "Scarlet Rune","minecraft:rarity": "uncommon","enchantment_glint_override": true,"enchantments":{"nderham:potency":1}}}}
summon item ^ ^.5 ^.5 {Item:{id:"minecraft:elder_guardian_spawn_egg",components:{"!entity_data":{},"item_model":"nderham:scarlet_rune_regulate","minecraft:item_name": "Scarlet Rune","minecraft:rarity": "uncommon","enchantment_glint_override": true,"enchantments":{"nderham:regulate":1}}}}
summon item ^ ^.5 ^.5 {Item:{id:"drowned_spawn_egg",components:{"item_model":"nderham:scarlet_emerald","item_name":"Scarlet Emerald","enchantment_glint_override":true,"rarity":"uncommon"}}}
summon item ^ ^.5 ^.5 {Item:{id:"drowned_spawn_egg",components:{"item_model":"nderham:scarlet_emerald","item_name":"Scarlet Emerald","enchantment_glint_override":true,"rarity":"uncommon"}}}
summon item ^ ^.5 ^.5 {Item:{id:"drowned_spawn_egg",components:{"item_model":"nderham:scarlet_emerald","item_name":"Scarlet Emerald","enchantment_glint_override":true,"rarity":"uncommon"}}}
summon item ^ ^.5 ^.5 {Item:{id:"drowned_spawn_egg",components:{"item_model":"nderham:scarlet_emerald","item_name":"Scarlet Emerald","enchantment_glint_override":true,"rarity":"uncommon"}}}
summon item ^ ^.5 ^.5 {Item:{id:"gold_ingot"}}
summon item ^ ^.5 ^.5 {Item:{id:"gold_ingot"}}

execute positioned ^ ^.5 ^.5 as @e[type=item,distance=..0.1,sort=nearest] run function nderham:random_motion
playsound minecraft:block.respawn_anchor.deplete player @a ^ ^.5 ^.5 1 0.5
playsound minecraft:block.respawn_anchor.deplete player @a ^ ^.5 ^.5 1 0.75
playsound minecraft:block.glass.break player @a ^ ^.5 ^.5 1 0.5
playsound minecraft:block.glass.break player @a ^ ^.5 ^.5 1 0.75
particle minecraft:dust{color:[0,0.75,1],scale:1} ^ ^.5 ^.5 0.25 0.25 0.25 0 5 force
kill @s