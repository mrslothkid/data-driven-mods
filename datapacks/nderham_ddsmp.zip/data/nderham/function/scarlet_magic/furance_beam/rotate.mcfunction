execute store result storage nderham:ritual id int 1 run scoreboard players get @s nderham.ritual.id
function nderham:scarlet_magic/furance_beam/rotate_apply with storage nderham:ritual
data remove entity @s interaction