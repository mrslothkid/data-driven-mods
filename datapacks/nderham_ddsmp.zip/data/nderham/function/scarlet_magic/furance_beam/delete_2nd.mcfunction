$kill @e[tag=nderham.ritual.furnace_beam.aim,type=marker,limit=1,scores={nderham.ritual.id=$(id)}]
$kill @e[tag=nderham.ritual.furnace_beam.slow_aim,type=marker,limit=1,scores={nderham.ritual.id=$(id)}]
$kill @e[tag=nderham.ritual.furnace_beam,type=marker,limit=1,scores={nderham.ritual.id=$(id)}]
$kill @e[tag=nderham.ritual.furnace_beam.interaction,type=interaction,limit=1,scores={nderham.ritual.id=$(id)}]
