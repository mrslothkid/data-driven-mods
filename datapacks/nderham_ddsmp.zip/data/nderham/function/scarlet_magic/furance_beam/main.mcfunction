execute as @e[type=egg,predicate=nderham:egg_furnace_beam] at @s run function nderham:scarlet_magic/furance_beam/create
execute as @e[tag=nderham.ritual.furnace_beam.interaction] if data entity @s attack at @s run playsound minecraft:entity.player.attack.strong player @a ^ ^.5 ^ 1 1
execute as @e[tag=nderham.ritual.furnace_beam.interaction] if data entity @s attack run scoreboard players add @s nderham.ritual.damage 1
execute as @e[tag=nderham.ritual.furnace_beam.interaction] if data entity @s attack run data remove entity @s attack
execute as @e[tag=nderham.ritual.furnace_beam.interaction,scores={nderham.ritual.damage=4..}] at @s run function nderham:scarlet_magic/furance_beam/delete
scoreboard players add @e[tag=nderham.ritual.furnace_beam.interaction,scores={nderham.ritual.damage=1..}] nderham.ritual.time 1
scoreboard players remove @e[tag=nderham.ritual.furnace_beam.interaction,scores={nderham.ritual.time=20..}] nderham.ritual.damage 1
scoreboard players set @e[tag=nderham.ritual.furnace_beam.interaction,scores={nderham.ritual.time=20..}] nderham.ritual.time 0
execute as @e[tag=nderham.ritual.furnace_beam.interaction] at @s if entity @e[tag=nderham.ritual.chaos_marble,scores={nderham.ritual.time=25},distance=..8] run scoreboard players set @s nderham.ritual.damage 1000

execute as @e[tag=nderham.ritual.furnace_beam.interaction] if data entity @s interaction run function nderham:scarlet_magic/furance_beam/rotate