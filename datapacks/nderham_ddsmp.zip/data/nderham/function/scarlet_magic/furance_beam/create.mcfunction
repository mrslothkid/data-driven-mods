execute on origin at @s rotated ~ 0 anchored eyes positioned ^ ^ ^1.5 rotated as @s run function nderham:scarlet_magic/ritual/create/furnace_beam
kill @s