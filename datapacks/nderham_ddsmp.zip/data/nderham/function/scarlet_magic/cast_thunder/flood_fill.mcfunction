execute if score cast_thunder.flood_fill nderham.value matches 10000.. run return 0
execute positioned ~ ~ ~ if entity @e[tag=nderham.cast_thunder.flood_fill,distance=..0.5,limit=1,type=marker] run return 0
summon marker ~ ~ ~ {Tags:["nderham.cast_thunder.flood_fill"]}
particle end_rod ~ ~ ~ 0 0 0 0 1 force
scoreboard players add cast_thunder.flood_fill nderham.value 1
#setblock ~ ~ ~ air