execute positioned ~1 ~ ~ if block ~ ~ ~ water run function nderham:scarlet_magic/cast_thunder/flood_fill
execute positioned ~ ~1 ~ if block ~ ~ ~ water run function nderham:scarlet_magic/cast_thunder/flood_fill
execute positioned ~ ~ ~1 if block ~ ~ ~ water run function nderham:scarlet_magic/cast_thunder/flood_fill
execute positioned ~-1 ~ ~ if block ~ ~ ~ water run function nderham:scarlet_magic/cast_thunder/flood_fill
execute positioned ~ ~-1 ~ if block ~ ~ ~ water run function nderham:scarlet_magic/cast_thunder/flood_fill
execute positioned ~ ~ ~-1 if block ~ ~ ~ water run function nderham:scarlet_magic/cast_thunder/flood_fill
scoreboard players add @s nderham.value 1
kill @s[scores={nderham.value=2..}]