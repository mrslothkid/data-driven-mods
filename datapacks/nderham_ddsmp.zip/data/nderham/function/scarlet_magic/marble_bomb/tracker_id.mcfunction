execute store result storage nderham:marble_bomb id int 1 run scoreboard players get @s nderham.marble_bomb.id
function nderham:scarlet_magic/marble_bomb/tracker with storage nderham:marble_bomb