tag @s add nderham.marble_bomb
tag @s add nderham.marble_bomb.init
execute store result score @s nderham.marble_bomb.id run random value 1..2147483647
summon marker ~ ~ ~ {Tags:["nderham.marble_bomb.tracker","nderham.marble_bomb.tracker.init"]}
scoreboard players operation @e[tag=nderham.marble_bomb.tracker.init,limit=1,sort=nearest,distance=..1,type=marker] nderham.marble_bomb.id = @s nderham.marble_bomb.id
#data modify entity @e[tag=nderham.marble_bomb.tracker.init,limit=1,sort=nearest,distance=..1,type=marker] Owner set from entity @s Owner

tag @s remove nderham.marble_bomb.init
tag @e[tag=nderham.marble_bomb.tracker.init,limit=1,sort=nearest,distance=..1,type=marker] remove nderham.marble_bomb.tracker.init