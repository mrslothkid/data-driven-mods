$tp @s @e[tag=nderham.marble_bomb,limit=1,type=egg,scores={nderham.marble_bomb.id=$(id)}]
$execute unless entity @e[tag=nderham.marble_bomb,limit=1,type=egg,scores={nderham.marble_bomb.id=$(id)}] positioned ~ ~.5 ~ run function nderham:scarlet_magic/ritual/create/chaos_marble
$execute unless entity @e[tag=nderham.marble_bomb,limit=1,type=egg,scores={nderham.marble_bomb.id=$(id)}] run kill @s