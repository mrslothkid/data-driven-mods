execute as @e[type=lightning_bolt,tag=!nderham.lightning_craft.detected] at @s run function nderham:lightning_craft/zap
execute as @e[type=lightning_bolt] at @s run function nderham:lightning_craft/effect_check
execute as @e[tag=nderham.lightning_craft.marker] at @s unless block ~ ~ ~ blast_furnace run kill @s

scoreboard players add @e[type=marker,tag=nderham.cast_thunder.flood_fill] nderham.value 0
execute as @e[type=marker,tag=nderham.cast_thunder.flood_fill,scores={nderham.value=0}] at @s run function nderham:scarlet_magic/cast_thunder/tick
execute if score cast_thunder.flood_fill nderham.value matches 10000.. run kill @e[type=marker,tag=nderham.cast_thunder.flood_fill]
execute if score cast_thunder.flood_fill nderham.value matches 10000.. run scoreboard players set cast_thunder.flood_fill nderham.value 0


function nderham:scarlet_magic/ritual/main


function nderham:scarlet_magic/thunder_alter/main

function nderham:scarlet_magic/marble_bomb/main
function nderham:scarlet_magic/furance_beam/main

execute as @a run function nderham:scarlet_magic/rune_update

execute as @a at @s as @e[type=chicken,predicate=nderham:erase_chicken,distance=..50] at @s run function nderham:erase_chicken
