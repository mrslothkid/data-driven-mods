tellraw @a "zap zap"
schedule function nderham:lightning_craft/check_loop 1s replace

scoreboard objectives add nderham.value dummy
scoreboard objectives add nderham.timer dummy
scoreboard objectives add nderham.math dummy
scoreboard objectives add nderham.rot_fix dummy

scoreboard objectives add nderham.thunder_alter.sound_loop dummy
scoreboard objectives add nderham.thunder_alter.fuel dummy
scoreboard objectives add nderham.thunder_alter.charge dummy

scoreboard objectives add nderham.marble_bomb.id dummy

scoreboard objectives add nderham.ritual.id dummy
scoreboard objectives add nderham.ritual.visual.spin dummy
scoreboard objectives add nderham.ritual.visual.directional_rot dummy
scoreboard objectives add nderham.ritual.visual.distance dummy
scoreboard objectives add nderham.ritual.visual.height dummy
scoreboard objectives add nderham.ritual.time dummy
scoreboard objectives add nderham.ritual.damage dummy
scoreboard objectives add nderham.ritual.visual.interp dummy

scoreboard players set $480 nderham.math 480
scoreboard players set $1 nderham.math 1