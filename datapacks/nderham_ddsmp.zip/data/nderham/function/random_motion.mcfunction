execute store result storage nderham:random_motion x float 0.01 run random value -40..40
execute store result storage nderham:random_motion y float 0.01 run random value -40..40
execute store result storage nderham:random_motion z float 0.01 run random value -40..40
function nderham:random_motion_apply with storage nderham:random_motion