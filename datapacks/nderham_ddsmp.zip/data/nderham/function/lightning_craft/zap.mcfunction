tag @s add nderham.lightning_craft.detected

execute align xyz positioned ~0.5 ~0.5 ~0.5 if block ~ ~-2 ~ blast_furnace if block ~ ~-3 ~ lodestone run return run function nderham:lightning_craft/craft
execute positioned ~ ~1 ~ align xyz positioned ~0.5 ~0.5 ~0.5 if block ~ ~-2 ~ blast_furnace if block ~ ~-3 ~ lodestone run return run function nderham:lightning_craft/craft
