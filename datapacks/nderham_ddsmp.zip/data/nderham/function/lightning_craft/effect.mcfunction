fill ~ ~-2 ~ ~ ~-2 ~ blast_furnace[lit=true,facing=north] replace blast_furnace[facing=north]
fill ~ ~-2 ~ ~ ~-2 ~ blast_furnace[lit=true,facing=south] replace blast_furnace[facing=south]
fill ~ ~-2 ~ ~ ~-2 ~ blast_furnace[lit=true,facing=west] replace blast_furnace[facing=west]
fill ~ ~-2 ~ ~ ~-2 ~ blast_furnace[lit=true,facing=east] replace blast_furnace[facing=east]
data modify block ~ ~-2 ~ lit_time_remaining set value 64
data modify block ~ ~-2 ~ speed_multiplier set value 100000.0
data modify block ~ ~-2 ~ lit_total_time set value 64
#data modify block ~ ~-2 ~ cooking_total_time set value 1


execute positioned ~ ~-2 ~ run particle minecraft:electric_spark ~0.5 ~ ~0.5 0 0.25 0 0.05 2 force
execute positioned ~ ~-2 ~ run particle minecraft:electric_spark ~-0.5 ~ ~0.5 0 0.25 0 0.05 2 force
execute positioned ~ ~-2 ~ run particle minecraft:electric_spark ~0.5 ~ ~-0.5 0 0.25 0 0.05 2 force
execute positioned ~ ~-2 ~ run particle minecraft:electric_spark ~-0.5 ~ ~-0.5 0 0.25 0 0.05 2 force

execute positioned ~ ~-2 ~ run particle minecraft:electric_spark ~0.5 ~0.5 ~ 0 0 0.25 0.05 2 force
execute positioned ~ ~-2 ~ run particle minecraft:electric_spark ~-0.5 ~0.5 ~ 0 0 0.25 0.05 2 force
execute positioned ~ ~-2 ~ run particle minecraft:electric_spark ~0.5 ~-0.5 ~ 0 0 0.25 0.05 2 force
execute positioned ~ ~-2 ~ run particle minecraft:electric_spark ~-0.5 ~-0.5 ~ 0 0 0.25 0.05 2 force

execute positioned ~ ~-2 ~ run particle minecraft:electric_spark ~ ~0.5 ~0.5 0.25 0 0 0.05 2 force
execute positioned ~ ~-2 ~ run particle minecraft:electric_spark ~ ~-0.5 ~0.5 0.25 0 0 0.05 2 force
execute positioned ~ ~-2 ~ run particle minecraft:electric_spark ~ ~0.5 ~-0.5 0.25 0 0 0.05 2 force
execute positioned ~ ~-2 ~ run particle minecraft:electric_spark ~ ~-0.5 ~-0.5 0.25 0 0 0.05 2 force




execute positioned ~ ~-3 ~ run particle minecraft:electric_spark ~0.5 ~ ~0.5 0 0.25 0 0.05 2 force
execute positioned ~ ~-3 ~ run particle minecraft:electric_spark ~-0.5 ~ ~0.5 0 0.25 0 0.05 2 force
execute positioned ~ ~-3 ~ run particle minecraft:electric_spark ~0.5 ~ ~-0.5 0 0.25 0 0.05 2 force
execute positioned ~ ~-3 ~ run particle minecraft:electric_spark ~-0.5 ~ ~-0.5 0 0.25 0 0.05 2 force

#execute positioned ~ ~-3 ~ run particle minecraft:electric_spark ~0.5 ~0.5 ~ 0 0 0.25 0.05 2 force
#execute positioned ~ ~-3 ~ run particle minecraft:electric_spark ~-0.5 ~0.5 ~ 0 0 0.25 0.05 2 force
execute positioned ~ ~-3 ~ run particle minecraft:electric_spark ~0.5 ~-0.5 ~ 0 0 0.25 0.05 2 force
execute positioned ~ ~-3 ~ run particle minecraft:electric_spark ~-0.5 ~-0.5 ~ 0 0 0.25 0.05 2 force

#execute positioned ~ ~-3 ~ run particle minecraft:electric_spark ~ ~0.5 ~0.5 0.25 0 0 0.05 2 force
execute positioned ~ ~-3 ~ run particle minecraft:electric_spark ~ ~-0.5 ~0.5 0.25 0 0 0.05 2 force
#execute positioned ~ ~-3 ~ run particle minecraft:electric_spark ~ ~0.5 ~-0.5 0.25 0 0 0.05 2 force
execute positioned ~ ~-3 ~ run particle minecraft:electric_spark ~ ~-0.5 ~-0.5 0.25 0 0 0.05 2 force