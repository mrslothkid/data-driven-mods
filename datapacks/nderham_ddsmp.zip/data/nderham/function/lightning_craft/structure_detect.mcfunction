execute if entity @e[tag=nderham.lightning_craft.marker,sort=nearest,distance=..0.5] run return 0
scoreboard players set lightning_craft.detect nderham.value 0

execute if block ~ ~ ~ blast_furnace run scoreboard players add lightning_craft.detect nderham.value 1
execute if block ~ ~1 ~ #lightning_rods run scoreboard players add lightning_craft.detect nderham.value 1
execute if block ~ ~-1 ~ lodestone run scoreboard players add lightning_craft.detect nderham.value 1

execute if score lightning_craft.detect nderham.value matches 3 run function nderham:lightning_craft/give_marker