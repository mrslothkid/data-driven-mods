playsound minecraft:block.respawn_anchor.set_spawn block @a ~ ~ ~ 1 1
playsound minecraft:block.respawn_anchor.set_spawn block @a ~ ~ ~ 1 1.5
playsound minecraft:block.respawn_anchor.set_spawn block @a ~ ~ ~ 1 2


execute unless items block ~ ~-2 ~ container.0 #nderham:lightning_craft_ingredient run return 0

data modify storage nderham:lightning_craft input set from block ~ ~-2 ~ Items[{Slot:0b}]
execute store result score lightning_craft.input_count nderham.value run data get block ~ ~-2 ~ Items[{Slot:0b}].count
data modify storage nderham:lightning_craft output set from block ~ ~-2 ~ Items[{Slot:2b}]
execute store result score lightning_craft.output_count nderham.value run data get block ~ ~-2 ~ Items[{Slot:2b}].count

execute if score lightning_craft.output_count nderham.value matches 64.. run return 0

execute if items block ~ ~-2 ~ container.0 magma_block positioned ~ ~-2 ~ run return run function nderham:lightning_craft/recipe/blaze_powder
execute if items block ~ ~-2 ~ container.0 emerald positioned ~ ~-2 ~ run return run function nderham:lightning_craft/recipe/scarlet_emerald
