execute as @a at @s anchored eyes positioned ^ ^ ^.01 run function nderham:lightning_craft/find_raycast
schedule function nderham:lightning_craft/check_loop 0.5s