execute if items block ~ ~ ~ container.2 * unless items block ~ ~ ~ container.2 drowned_spawn_egg run return 0

scoreboard players remove lightning_craft.input_count nderham.value 1
execute if score lightning_craft.input_count nderham.value matches 0 run item override block ~ ~ ~ container.0 with air
execute store result block ~ ~ ~ Items[{Slot:0b}].count int 1 run scoreboard players get lightning_craft.input_count nderham.value

scoreboard players add lightning_craft.output_count nderham.value 1
execute if score lightning_craft.output_count nderham.value matches 1 run item override block ~ ~ ~ container.2 with drowned_spawn_egg[item_model="nderham:scarlet_emerald",item_name="Scarlet Emerald",enchantment_glint_override=true,rarity=uncommon]
execute store result block ~ ~ ~ Items[{Slot:2b}].count int 1 run scoreboard players get lightning_craft.output_count nderham.value