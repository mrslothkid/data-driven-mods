execute align xyz positioned ~0.5 ~0.5 ~0.5 if block ~ ~-2 ~ blast_furnace if block ~ ~-3 ~ lodestone run function nderham:lightning_craft/effect
execute positioned ~ ~1 ~ align xyz positioned ~0.5 ~0.5 ~0.5 if block ~ ~-2 ~ blast_furnace if block ~ ~-3 ~ lodestone run function nderham:lightning_craft/effect
