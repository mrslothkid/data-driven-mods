#fill ~ ~ ~ ~ ~ ~ air replace fire
fill ~ ~ ~ ~ ~ ~ terracotta replace #nderham:burn/terracotta
fill ~ ~ ~ ~ ~ ~ coarse_dirt replace #nderham:burn/coarse_dirt
fill ~ ~ ~ ~ ~ ~ dirt replace #nderham:burn/dirt
fill ~ ~ ~ ~ ~ ~ fire replace #nderham:burn/fire

fill ~ ~ ~ ~ ~ ~ air replace snow
fill ~ ~ ~ ~ ~ ~ air replace snow_block
fill ~ ~ ~ ~ ~ ~ air replace powder_snow
fill ~ ~ ~ ~ ~ ~ air replace water
fill ~ ~ ~ ~ ~ ~ air replace ice
fill ~ ~ ~ ~ ~ ~ ice replace packed_ice
fill ~ ~ ~ ~ ~ ~ packed_ice replace blue_ice