

#$execute at @s run data modify entity @n[tag=sloths_display] block_state.id set from storage slothsdisplayeditor:dictionary replaceblock."$(id)"

#execute if data entity @s equipment.offhand.id run data modify entity @n[type=block_display,tag=sloths_new_display] block_state.id set from entity @s equipment.offhand.id

#hardcode all of the blocks that have different item and block ids identical to dictionary
#data modify storage slothsdisplayeditor:dictionary replaceblock set value {"minecraft:wheat_seeds":"minecraft:wheat", "minecraft:pumpkin_seeds":"minecraft:pumpkin_stem", "minecraft:melon_seeds":"minecraft:melon_stem", "minecraft:carrot":"minecraft:carrots", "minecraft:potato":"minecraft:potatoes", "minecraft:sweet_berries":"minecraft:sweet_berry_bush", "minecraft:pitcher_pod":"minecraft:pitcher_crop", "minecraft:redstone":"minecraft:redstone_wire", "minecraft:string":"minecraft:tripwire", "water_bucket":"minecraft:water", "lava_bucket":"minecraft:lava", "powder_snow_bucket":"minecraft:powder_snow"}

execute if items entity @s weapon.offhand minecraft:wheat_seeds run data modify entity @n[type=block_display,tag=sloths_new_display] block_state.id set value "minecraft:wheat"
execute if items entity @s weapon.offhand minecraft:pumpkin_seeds run data modify entity @n[type=block_display,tag=sloths_new_display] block_state.id set value "minecraft:pumpkin_stem"
execute if items entity @s weapon.offhand minecraft:melon_seeds run data modify entity @n[type=block_display,tag=sloths_new_display] block_state.id set value "minecraft:melon_stem"
execute if items entity @s weapon.offhand minecraft:carrot run data modify entity @n[type=block_display,tag=sloths_new_display] block_state.id set value "minecraft:carrots"
execute if items entity @s weapon.offhand minecraft:potato run data modify entity @n[type=block_display,tag=sloths_new_display] block_state.id set value "minecraft:potatoes"
execute if items entity @s weapon.offhand minecraft:sweet_berries run data modify entity @n[type=block_display,tag=sloths_new_display] block_state.id set value "minecraft:sweet_berry_bush"
execute if items entity @s weapon.offhand minecraft:pitcher_pod run data modify entity @n[type=block_display,tag=sloths_new_display] block_state.id set value "minecraft:pitcher_crop"
execute if items entity @s weapon.offhand minecraft:redstone run data modify entity @n[type=block_display,tag=sloths_new_display] block_state.id set value "minecraft:redstone_wire"
execute if items entity @s weapon.offhand minecraft:string run data modify entity @n[type=block_display,tag=sloths_new_display] block_state.id set value "minecraft:tripwire"
execute if items entity @s weapon.offhand minecraft:water_bucket run data modify entity @n[type=block_display,tag=sloths_new_display] block_state.id set value "minecraft:water"
execute if items entity @s weapon.offhand minecraft:lava_bucket run data modify entity @n[type=block_display,tag=sloths_new_display] block_state.id set value "minecraft:lava"
execute if items entity @s weapon.offhand minecraft:powder_snow_bucket run data modify entity @n[type=block_display,tag=sloths_new_display] block_state.id set value "minecraft:powder_snow"

execute if items entity @s weapon.offhand minecraft:flint_and_steel run data modify entity @n[type=block_display,tag=sloths_new_display] block_state.id set value "minecraft:fire"


