
#tellraw @s "Highlighting Nearest Display Entity..."
tellraw @s [{text:"[",color:white},{text:"!",color:green},{text:"]",color:white},{text:" Highlighting Nearest Display Entity...",color:green}]

execute as @n[tag=sloths_display] run scoreboard players set @s slothsdisplayeditor.modify 61
