

execute if score $modify_entity_magnitude slothsdisplayeditor.modify matches 0 run data modify entity @n[tag=sloths_display] block_state.Properties.attachment set value "ceiling"
execute if score $modify_entity_magnitude slothsdisplayeditor.modify matches 1 run data modify entity @n[tag=sloths_display] block_state.Properties.attachment set value "double_wall"
execute if score $modify_entity_magnitude slothsdisplayeditor.modify matches 2 run data modify entity @n[tag=sloths_display] block_state.Properties.attachment set value "floor"
execute if score $modify_entity_magnitude slothsdisplayeditor.modify matches 3 run data modify entity @n[tag=sloths_display] block_state.Properties.attachment set value "single_wall"
