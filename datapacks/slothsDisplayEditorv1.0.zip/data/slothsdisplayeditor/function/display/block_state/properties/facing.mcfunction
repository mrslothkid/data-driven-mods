

execute if score $modify_entity_magnitude slothsdisplayeditor.modify matches 0 run data modify entity @n[tag=sloths_display] block_state.Properties.facing set value "down"
execute if score $modify_entity_magnitude slothsdisplayeditor.modify matches 1 run data modify entity @n[tag=sloths_display] block_state.Properties.facing set value "east"
execute if score $modify_entity_magnitude slothsdisplayeditor.modify matches 2 run data modify entity @n[tag=sloths_display] block_state.Properties.facing set value "north"
execute if score $modify_entity_magnitude slothsdisplayeditor.modify matches 3 run data modify entity @n[tag=sloths_display] block_state.Properties.facing set value "south"
execute if score $modify_entity_magnitude slothsdisplayeditor.modify matches 4 run data modify entity @n[tag=sloths_display] block_state.Properties.facing set value "west"
execute if score $modify_entity_magnitude slothsdisplayeditor.modify matches 5 run data modify entity @n[tag=sloths_display] block_state.Properties.facing set value "up"

