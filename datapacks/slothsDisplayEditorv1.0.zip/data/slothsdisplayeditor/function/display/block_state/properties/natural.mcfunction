

execute if score $modify_entity_magnitude slothsdisplayeditor.modify matches 0 run data modify entity @n[tag=sloths_display] block_state.Properties.natural set value "false"
execute if score $modify_entity_magnitude slothsdisplayeditor.modify matches 1 run data modify entity @n[tag=sloths_display] block_state.Properties.natural set value "true"
