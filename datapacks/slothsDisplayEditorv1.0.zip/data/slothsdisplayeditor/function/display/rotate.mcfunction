

#tellraw @a [{text: "Rotate with magnitude "}, {"score":{"name":"$modify_entity_magnitude","objective":"slothsdisplayeditor.modify"}}, {text: " on axis "}, {"score":{"name":"$modify_entity_axis","objective":"slothsdisplayeditor.modify"}} ]

#something something rotate
#use the x y and z type rotate 
# needs to use the quack datapack (now built in) to run the quarternion calcs


$execute if score $modify_entity_axis slothsdisplayeditor.modify matches 2 run data modify storage quack:api euler set value [$(magnitude)f, 0f, 0f]
$execute if score $modify_entity_axis slothsdisplayeditor.modify matches 1 run data modify storage quack:api euler set value [0f, $(magnitude)f, 0f]
$execute if score $modify_entity_axis slothsdisplayeditor.modify matches 3 run data modify storage quack:api euler set value [0f, 0f, $(magnitude)f]

execute at @s run function quack:api/storage/euler_to_quaternion


data modify storage quack:api quaternions.a set from entity @n[tag=sloths_display] transformation.left_rotation

data modify storage quack:api quaternions.b set from storage quack:api quaternion


execute at @s run function quack:api/storage/multiply_quaternions

data modify entity @n[tag=sloths_display] transformation.left_rotation set from storage quack:api quaternions.out


#data modify entity @s transformation.left_rotation set value {axis:[0.0f,0.0f,1.0f],angle:###}
