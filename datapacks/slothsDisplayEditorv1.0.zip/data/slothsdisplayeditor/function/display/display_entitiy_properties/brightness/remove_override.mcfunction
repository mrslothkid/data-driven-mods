
data remove entity @n[tag=sloths_display] brightness
