
execute unless data entity @n[tag=sloths_display] brightness run data modify entity @n[tag=sloths_display] brightness set value {block:0, sky:0}
