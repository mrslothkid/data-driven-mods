

#$data modify entity @n[tag=sloths_display] brightness.block set value $(magnitude)
execute store result entity @n[tag=sloths_display] brightness.block int 1 run data get storage slothsdisplayeditor:temp magnitude 1

#$data merge entity @n[tag=sloths_display] {brightness:{block:$(magnitude)}}

