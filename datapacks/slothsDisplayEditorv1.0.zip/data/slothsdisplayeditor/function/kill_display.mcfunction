
execute at @n[tag=sloths_display] run summon item ~ ~ ~ {Item:{id:"stone",count:1}}

#i just thought i kinda wanna do something like
#execute if nearest slothsdisplay is an item display run function xyz
#execute if nearest slothsdisplay is a block display run function abc

execute as @n[tag=sloths_display,distance=..10] if entity @s[type=item_display] run function slothsdisplayeditor:kill/item_display
execute as @n[tag=sloths_display,distance=..10] if entity @s[type=block_display] run function slothsdisplayeditor:kill/block_display


# holy fuck is this directory unreadable
# girl i didnt expect anyone to read this datapack
# I don't either and I do make it nicer for myself, cuz else I have no idea what does what. at this point name them 1, 2, 3
# well u can fix it if you want but
# rather not ;-;
# mrau :3



kill @n[tag=sloths_display]
