

#block displays
#execute as @n[type=block_display,distance=..10] run function slothsdisplayeditor:kill/display_set_item

#execute as @n[type=block_display,tag=sloths_display,distance=..10] at @s run function slothsdisplayeditor:kill/check_block_state


execute if data entity @s block_state{Name:"minecraft:wheat"} run return run data modify entity @n[type=item,distance=..3] Item.id set value "minecraft:wheat_seeds"
execute if data entity @s block_state{Name:"minecraft:pumpkin_stem"} run return run data modify entity @n[type=item,distance=..3] Item.id set value "minecraft:pumpkin_seeds"
execute if data entity @s block_state{Name:"minecraft:melon_stem"} run return run data modify entity @n[type=item,distance=..3] Item.id set value "minecraft:melon_seeds"
execute if data entity @s block_state{Name:"minecraft:carrots"} run return run data modify entity @n[type=item,distance=..3] Item.id set value "minecraft:carrot"
execute if data entity @s block_state{Name:"minecraft:potatoes"} run return run data modify entity @n[type=item,distance=..3] Item.id set value "minecraft:potato"
execute if data entity @s block_state{Name:"minecraft:sweet_berry_bush"} run return run data modify entity @n[type=item,distance=..3] Item.id set value "minecraft:sweet_berries"
execute if data entity @s block_state{Name:"minecraft:pitcher_crop"} run return run data modify entity @n[type=item,distance=..3] Item.id set value "minecraft:pitcher_pod"
execute if data entity @s block_state{Name:"minecraft:redstone_wire"} run return run data modify entity @n[type=item,distance=..3] Item.id set value "minecraft:redstone"
execute if data entity @s block_state{Name:"minecraft:water"} run return run data modify entity @n[type=item,distance=..3] Item.id set value "minecraft:water_bucket"
execute if data entity @s block_state{Name:"minecraft:lava"} run return run data modify entity @n[type=item,distance=..3] Item.id set value "minecraft:lava_bucket"
execute if data entity @s block_state{Name:"minecraft:powder_snow"} run return run data modify entity @n[type=item,distance=..3] Item.id set value "minecraft:powder_snow_bucket"

execute if data entity @s block_state{Name:"minecraft:fire"} run return run data modify entity @n[type=item,distance=..3] Item.id set value "minecraft:flint_and_steel"


data modify entity @n[type=item,distance=..3] Item.id set from entity @n[type=block_display,tag=sloths_display] block_state.Name

#redstone/redstone_wire and string/tripwire have to be hardcoded because the item and block have different names
#also the other ones do but i also cant get it working

