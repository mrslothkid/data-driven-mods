

#item displays
execute at @n[type=item_display,tag=sloths_display,distance=..10] run item replace entity @n[type=item,distance=..3] contents from entity @n[tag=sloths_display] contents {function:"minecraft:set_count",count:1}

