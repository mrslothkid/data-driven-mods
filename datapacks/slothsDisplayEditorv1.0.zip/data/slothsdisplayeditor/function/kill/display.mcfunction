
execute at @n[tag=sloths_display] run summon item ~ ~ ~ {Item:{id:"stone",count:1}}



execute as @n[tag=sloths_display,distance=..10] at @s if entity @s[type=item_display] run function slothsdisplayeditor:kill/item_display
execute as @n[tag=sloths_display,distance=..10] at @s if entity @s[type=block_display] run function slothsdisplayeditor:kill/block_display



kill @n[tag=sloths_display]
