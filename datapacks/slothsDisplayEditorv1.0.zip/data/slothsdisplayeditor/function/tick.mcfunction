
#page 1 of book
#summon
#only run if not holding air in offhand
#item display
execute as @a at @s if score @s slothsdisplayeditor.modify matches 1 unless items entity @s weapon.offhand * run tellraw @s [{"text":"[","color":"white"},{"text":"!","color":"green"},{"text":"] ","color":"white"},{"text":"You must be holding an item in your offhand to perform this action!","color":"red"}]
execute as @a at @s if score @s slothsdisplayeditor.modify matches 1 if items entity @s weapon.offhand * run function slothsdisplayeditor:summon/summon_item_display

#block display
execute as @a at @s if score @s slothsdisplayeditor.modify matches 2 unless items entity @s weapon.offhand * run tellraw @s [{"text":"[","color":"white"},{"text":"!","color":"green"},{"text":"] ","color":"white"},{"text":"You must be holding a block in your offhand to perform this action!","color":"red"}]
execute as @a at @s if score @s slothsdisplayeditor.modify matches 2 if items entity @s weapon.offhand * run function slothsdisplayeditor:summon/summon_block_display

#kill
#only run if there is a display entity within 10 blocks
execute as @a at @s if score @s slothsdisplayeditor.modify matches 3 unless entity @n[tag=sloths_display,distance=..10] run tellraw @s [{"text":"[","color":"white"},{"text":"!","color":"green"},{"text":"] ","color":"white"},{"text":"No Display Entity found within 10 blocks!","color":"red"}]
execute as @a at @s if score @s slothsdisplayeditor.modify matches 3 if entity @n[tag=sloths_display,distance=..10] run function slothsdisplayeditor:kill/display

#highlight
#only run if there is a display entity within 10 blocks
execute as @a at @s if score @s slothsdisplayeditor.modify matches 4 unless entity @n[tag=sloths_display,distance=..10] run tellraw @s [{"text":"[","color":"white"},{"text":"!","color":"green"},{"text":"] ","color":"white"},{"text":"No Display Entity found within 10 blocks!","color":"red"}]
execute as @a at @s if score @s slothsdisplayeditor.modify matches 4 if entity @n[tag=sloths_display,distance=..10] run function slothsdisplayeditor:display/highlight

#update book
execute as @a at @s if score @s slothsdisplayeditor.modify matches 999 if items entity @s weapon.mainhand written_book run item modify entity @s weapon.mainhand slothsdisplayeditor:command_book
execute as @a at @s if score @s slothsdisplayeditor.modify matches 999 if items entity @s weapon.offhand written_book run item modify entity @s weapon.offhand slothsdisplayeditor:command_book
execute as @a at @s if score @s slothsdisplayeditor.modify matches 999 if items entity @s player.cursor written_book run item modify entity @s player.cursor slothsdisplayeditor:command_book


#if modify trigger isnt 1 2 3 or 4 then we extract the values and perform accordingly
#first digit is the operation translate/scale/rotate
#second and third digit are the axis x/y/z
#4th digit is positive or negative +/-
#5th and 6th are the pixel/degree rotation

#if first digit is 4 then its property modifier
#second and third digit are action, eg age/axis/delay/power etc etc
#4th digit is sub-action/category/idk how to explain
#5th and 6th are magnitude/truefalse/a-b-c/whatever

execute as @a if score @s slothsdisplayeditor.modify matches 100000.. run function slothsdisplayeditor:modify_item_display

execute as @e[tag=sloths_display,scores={slothsdisplayeditor.modify=2..}] run data modify entity @s Glowing set value 1b
execute as @e[tag=sloths_display,scores={slothsdisplayeditor.modify=1..2}] run data modify entity @s Glowing set value 0b
scoreboard players remove @e[tag=sloths_display,scores={slothsdisplayeditor.modify=1..}] slothsdisplayeditor.modify 1



scoreboard players reset @a slothsdisplayeditor.modify
scoreboard players enable @a slothsdisplayeditor.modify


execute as @a if items entity @s weapon.mainhand written_book[custom_data={"slothsdisplayeditor":"book"}] run trigger slothsdisplayeditor.modify set 999
execute as @a if items entity @s weapon.offhand written_book[custom_data={"slothsdisplayeditor":"book"}] run trigger slothsdisplayeditor.modify set 999

