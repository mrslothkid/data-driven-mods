

scoreboard objectives add slothsdisplayeditor.modify trigger modify_display
function quack:api/create_scoreboards

scoreboard players set $neg1 slothsdisplayeditor.modify -1
scoreboard players set $100 slothsdisplayeditor.modify 100
#625 is for the pixel count - 16 pixels to the coord, 0.0625 units per pixel
scoreboard players set $625 slothsdisplayeditor.modify 625
scoreboard players set $1000 slothsdisplayeditor.modify 1000
scoreboard players set $10000 slothsdisplayeditor.modify 10000
scoreboard players set $100000 slothsdisplayeditor.modify 100000


data modify storage slothsdisplayeditor:dictionary replaceblock set value {"minecraft:wheat_seeds":"minecraft:wheat", "minecraft:pumpkin_seeds":"minecraft:pumpkin_stem", "minecraft:melon_seeds":"minecraft:melon_stem", "minecraft:carrot":"minecraft:carrots", "minecraft:potato":"minecraft:potatoes", "minecraft:sweet_berries":"minecraft:sweet_berry_bush", "minecraft:pitcher_pod":"minecraft:pitcher_crop", "minecraft:redstone":"minecraft:redstone_wire", "minecraft:string":"minecraft:tripwire", "water_bucket":"minecraft:water", "lava_bucket":"minecraft:lava", "powder_snow_bucket":"minecraft:powder_snow"}
data modify storage slothsdisplayeditor:dictionary replaceitem set value {"minecraft:wheat":"minecraft:wheat_seeds", "minecraft:pumpkin_stem":"minecraft:pumpkin_seeds", "minecraft:melon_stem":"minecraft:melon_seeds", "minecraft:carrots":"minecraft:carrot", "minecraft:potatoes":"minecraft:potato", "minecraft:sweet_berry_bush":"minecraft:sweet_berries", "minecraft:pitcher_crop":"minecraft:pitcher_pod", "minecraft:redstone_wire":"minecraft:redstone", "minecraft:tripwire":"minecraft:string", "minecraft:water":"water_bucket", "minecraft:lava":"minecraft:lava_bucket", "minecraft:powder_snow":"minecraft:powder_snow_bucket"}

execute as SirSlothKid if entity @s[gamemode=creative] run scoreboard players set $initialised slothsdisplayeditor.modify 0
execute unless score $initialised slothsdisplayeditor.modify matches 1.. run tellraw @a [{text:"[",color:white},{text:"!",color:green},{text:"]",color:white},{text:" Slothy's Display Editor Loaded!",color:green}]


scoreboard players set $initialised slothsdisplayeditor.modify 1

