

#$execute at @s run data modify entity @n[tag=sloths_display] block_state.Name set from storage slothsdisplayeditor:dictionary replaceblock."$(id)"

#execute if data entity @s equipment.offhand.id run data modify entity @n[type=block_display,tag=sloths_new_display] block_state.Name set from entity @s equipment.offhand.id

#hardcode all of the blocks that have different item and block names identical to dictionary
#data modify storage slothsdisplayeditor:dictionary replaceblock set value {"minecraft:wheat_seeds":"minecraft:wheat", "minecraft:pumpkin_seeds":"minecraft:pumpkin_stem", "minecraft:melon_seeds":"minecraft:melon_stem", "minecraft:carrot":"minecraft:carrots", "minecraft:potato":"minecraft:potatoes", "minecraft:sweet_berries":"minecraft:sweet_berry_bush", "minecraft:pitcher_pod":"minecraft:pitcher_crop", "minecraft:redstone":"minecraft:redstone_wire", "minecraft:string":"minecraft:tripwire", "water_bucket":"minecraft:water", "lava_bucket":"minecraft:lava", "powder_snow_bucket":"minecraft:powder_snow"}

execute if data entity @s equipment.offhand{id:"minecraft:wheat_seeds"} run data modify entity @n[type=block_display,tag=sloths_new_display] block_state.Name set value "minecraft:wheat"
execute if data entity @s equipment.offhand{id:"minecraft:pumpkin_seeds"} run data modify entity @n[type=block_display,tag=sloths_new_display] block_state.Name set value "minecraft:pumpkin_stem"
execute if data entity @s equipment.offhand{id:"minecraft:melon_seeds"} run data modify entity @n[type=block_display,tag=sloths_new_display] block_state.Name set value "minecraft:melon_stem"
execute if data entity @s equipment.offhand{id:"minecraft:carrot"} run data modify entity @n[type=block_display,tag=sloths_new_display] block_state.Name set value "minecraft:carrots"
execute if data entity @s equipment.offhand{id:"minecraft:potato"} run data modify entity @n[type=block_display,tag=sloths_new_display] block_state.Name set value "minecraft:potatoes"
execute if data entity @s equipment.offhand{id:"minecraft:sweet_berries"} run data modify entity @n[type=block_display,tag=sloths_new_display] block_state.Name set value "minecraft:sweet_berry_bush"
execute if data entity @s equipment.offhand{id:"minecraft:pitcher_pod"} run data modify entity @n[type=block_display,tag=sloths_new_display] block_state.Name set value "minecraft:pitcher_crop"
execute if data entity @s equipment.offhand{id:"minecraft:redstone"} run data modify entity @n[type=block_display,tag=sloths_new_display] block_state.Name set value "minecraft:redstone_wire"
execute if data entity @s equipment.offhand{id:"minecraft:string"} run data modify entity @n[type=block_display,tag=sloths_new_display] block_state.Name set value "minecraft:tripwire"
execute if data entity @s equipment.offhand{id:"minecraft:water_bucket"} run data modify entity @n[type=block_display,tag=sloths_new_display] block_state.Name set value "minecraft:water"
execute if data entity @s equipment.offhand{id:"minecraft:lava_bucket"} run data modify entity @n[type=block_display,tag=sloths_new_display] block_state.Name set value "minecraft:lava"
execute if data entity @s equipment.offhand{id:"minecraft:powder_snow_bucket"} run data modify entity @n[type=block_display,tag=sloths_new_display] block_state.Name set value "minecraft:powder_snow"

execute if data entity @s equipment.offhand{id:"minecraft:flint_and_steel"} run data modify entity @n[type=block_display,tag=sloths_new_display] block_state.Name set value "minecraft:fire"


