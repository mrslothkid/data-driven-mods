
execute at @s align xyz run summon block_display ~0.5 ~0.5 ~0.5 {Tags:["sloths_new_display", "sloths_display"]}
#execute at @s align xyz run summon block_display ~ ~ ~ {Tags:["sloths_new_display", "sloths_display"]}


execute if data entity @s equipment.offhand.id run data modify entity @n[type=block_display,tag=sloths_new_display] block_state.Name set from entity @s equipment.offhand.id
#redstone dust the item is different from redstone_wire the block so it has to be hardcoded
#macro swap into dictionary ig
#or maybe it doesnt work so we hardcode it
#function slothsdisplayeditor:summon_block_change_block with entity @s equipment.offhand.id
function slothsdisplayeditor:summon/summon_block_change_block


execute unless data entity @s equipment.offhand.id run kill @n[type=block_display,tag=sloths_new_display]

data modify entity @n[type=block_display,tag=sloths_new_display] transformation.translation set value [-0.5,-0.5,-0.5]




execute unless data entity @n[type=block_display,tag=sloths_new_display] {block_state:{Name:"minecraft:air"}} run item modify entity @s weapon.offhand slothsdisplayeditor:decrement


execute if data entity @n[type=block_display,tag=sloths_new_display] {block_state:{Name:"minecraft:air"}} run tellraw @s [{"text":"[","color":"white"},{"text":"!","color":"green"},{"text":"] ","color":"white"},{"text":"Could not summon Block Display. Ensure you are holding a block, not an item. If the placed item should be a block, report this as a bug","color":"red"}]
execute if data entity @n[type=block_display,tag=sloths_new_display] {block_state:{Name:"minecraft:air"}} run kill @n[type=block_display,tag=sloths_new_display]


tag @e[type=block_display,tag=sloths_new_display] remove sloths_new_display

