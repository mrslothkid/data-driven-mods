execute as @a[tag=!used_eye] if score @s noxiouseye.eye.using matches 1.. run scoreboard players reset @s noxiouseye.eye.using
execute as @a[tag=used_eye] at @s run function noxiouseye:ender_eye/using_tick

execute as @a if score @s noxiouseye.eye.cooldown matches 1.. run scoreboard players remove @s noxiouseye.eye.cooldown 1