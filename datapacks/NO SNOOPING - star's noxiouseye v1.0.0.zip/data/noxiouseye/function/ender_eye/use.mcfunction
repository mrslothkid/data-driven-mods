advancement revoke @s only noxiouseye:i/use
execute unless score @s noxiouseye.eye.cooldown matches 1.. run tag @s add used_eye