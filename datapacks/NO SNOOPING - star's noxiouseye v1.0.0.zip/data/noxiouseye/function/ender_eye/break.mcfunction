playsound noxiouseye:eye_break player @a ~ ~ ~ 10.0
playsound minecraft:entity.ender_eye.death player @a ~ ~ ~ 10.0 0.25

clear @s *[minecraft:custom_data={"noxiouseye":"ender_eye"}] 1
give @s poisonous_potato[item_name={"translate":"noxiouseye.item.shattered_eye"},item_model="noxiouseye:shattered_eye",!food,!consumable,enchantment_glint_override=true,rarity=epic,max_stack_size=1]
advancement grant @s only noxiouseye:shattered_eye

scoreboard players reset @s noxiouseye.eye.using
scoreboard players set @s noxiouseye.eye.cooldown 30