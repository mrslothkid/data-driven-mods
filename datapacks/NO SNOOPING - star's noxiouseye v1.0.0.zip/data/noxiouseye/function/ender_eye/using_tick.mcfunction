scoreboard players add @s noxiouseye.eye.using 1
tag @s remove used_eye

execute if score @s noxiouseye.eye.using matches 1 run playsound noxiouseye:eye_hum player @a ~ ~ ~
execute anchored eyes run particle reverse_portal ^ ^ ^ 0.2 0.2 0.2 1.0 2

execute if score @s noxiouseye.eye.using matches 60.. run function noxiouseye:ender_eye/break