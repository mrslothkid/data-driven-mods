scoreboard objectives add noxiouseye.eye.using dummy
scoreboard objectives add noxiouseye.eye.cooldown dummy